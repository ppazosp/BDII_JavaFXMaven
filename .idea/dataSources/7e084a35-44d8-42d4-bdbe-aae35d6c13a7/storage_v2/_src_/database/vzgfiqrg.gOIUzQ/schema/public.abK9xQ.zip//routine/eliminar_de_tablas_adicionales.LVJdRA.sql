create function eliminar_de_tablas_adicionales() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.tipo = 'jugador_competitivo' THEN
        DELETE FROM public.jugador_competitivo WHERE id = OLD.user_id;
    ELSIF OLD.tipo = 'administrador' THEN
        DELETE FROM public.administrador WHERE id = OLD.user_id;
    ELSIF OLD.tipo = 'editor' THEN
        DELETE FROM public.editor WHERE id = OLD.user_id;
    END IF;
    RETURN OLD;
END;
$$;

alter function eliminar_de_tablas_adicionales() owner to vzgfiqrg;

