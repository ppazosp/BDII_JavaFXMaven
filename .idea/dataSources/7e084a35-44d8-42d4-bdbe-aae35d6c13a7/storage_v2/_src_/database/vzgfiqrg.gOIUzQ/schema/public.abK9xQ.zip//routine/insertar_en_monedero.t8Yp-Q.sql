create function insertar_en_monedero() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO monedero(id_comun, dinero)
    VALUES (NEW.user_id, 0);
    RETURN NEW;
END;
$$;

alter function insertar_en_monedero() owner to vzgfiqrg;

