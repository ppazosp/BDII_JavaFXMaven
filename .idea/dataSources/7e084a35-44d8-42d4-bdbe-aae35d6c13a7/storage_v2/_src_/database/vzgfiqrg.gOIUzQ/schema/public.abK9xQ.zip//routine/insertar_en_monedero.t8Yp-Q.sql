create function insertar_en_monedero() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verificar si ya existe una fila en monedero para este id_comun
    IF EXISTS (SELECT 1 FROM monedero WHERE id_comun = NEW.id) THEN
        -- Si ya existe, no hacer nada
        RETURN NEW;
    ELSE
        -- Si no existe, insertar una nueva fila con dinero 0
        INSERT INTO monedero(id_comun, dinero) VALUES (NEW.id, 0);
        RETURN NEW;
    END IF;
END;
$$;

alter function insertar_en_monedero() owner to vzgfiqrg;

