create function actualizar_monedero() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE monedero
    SET dinero = dinero + NEW.dinero
    WHERE id_comun = NEW.id;
    RETURN NEW;
END;
$$;

alter function actualizar_monedero() owner to vzgfiqrg;

