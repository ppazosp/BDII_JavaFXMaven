create function insertar_tipo_usuario() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO public.tipo_usuario(user_id, tipo)
    VALUES(NEW.id, 'comun');
    INSERT INTO public.comun(id)
    VALUES(NEW.id);
    INSERT INTO public.monedero(id_comun)
    VALUES(NEW.id);
    RETURN NEW;
END;
$$;

alter function insertar_tipo_usuario() owner to vzgfiqrg;

