create function insertar_en_tablas_adicionales() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.tipo = 'jugador_competitivo' THEN
        INSERT INTO public.jugador_competitivo(id)
        VALUES (NEW.user_id);
    ELSIF NEW.tipo = 'administrador' THEN
        INSERT INTO public.administrador(id)
        VALUES (NEW.user_id);
    ELSIF NEW.tipo = 'editor' THEN
        INSERT INTO public.editor(id)
        VALUES (NEW.user_id);
    END IF;
    RETURN NEW;
END;
$$;

alter function insertar_en_tablas_adicionales() owner to vzgfiqrg;

